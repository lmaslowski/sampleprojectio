import org.junit.jupiter.api.BeforeEach;
#parse("File Header.java")
public class ${NAME} {
    
    @BeforeEach
    void before() {
    }
}